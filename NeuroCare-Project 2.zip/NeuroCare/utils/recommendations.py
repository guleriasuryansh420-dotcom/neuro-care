"""
NeuroCare Clinical Recommendations & Health Intelligence Engine
Generates personalized clinical advice, biomarker insights, and actionable health guidance.
"""

def generate_diabetes_recommendations(inputs, risk_percentage, risk_level):
    """
    Generate tailored clinical recommendations based on diabetes inputs and predicted risk.
    """
    glucose = float(inputs.get('glucose', 0))
    bmi = float(inputs.get('bmi', 0))
    bp = float(inputs.get('blood_pressure', 0))
    insulin = float(inputs.get('insulin', 0))
    age = int(inputs.get('age', 0))

    biomarkers = []
    actions = []
    clinical_flags = []
    urgency = "Standard Routine"

    # Biomarker analysis
    if glucose >= 200:
        clinical_flags.append("Critical: Severe Hyperglycemia (Glucose >= 200 mg/dL)")
        biomarkers.append({"name": "Plasma Glucose", "value": f"{glucose} mg/dL", "status": "Critical High", "badge": "danger"})
    elif glucose >= 140:
        clinical_flags.append("Elevated: Impaired Glucose Tolerance (140-199 mg/dL)")
        biomarkers.append({"name": "Plasma Glucose", "value": f"{glucose} mg/dL", "status": "Prediabetic Range", "badge": "warning"})
    elif glucose > 0:
        biomarkers.append({"name": "Plasma Glucose", "value": f"{glucose} mg/dL", "status": "Normal Fasting / Post-prandial", "badge": "success"})

    if bmi >= 30:
        clinical_flags.append("Obesity Class: High BMI (>= 30.0 kg/m²)")
        biomarkers.append({"name": "BMI", "value": f"{bmi} kg/m²", "status": "Obese", "badge": "danger"})
    elif bmi >= 25:
        clinical_flags.append("Elevated BMI: Overweight (25.0 - 29.9 kg/m²)")
        biomarkers.append({"name": "BMI", "value": f"{bmi} kg/m²", "status": "Overweight", "badge": "warning"})
    elif bmi > 0:
        biomarkers.append({"name": "BMI", "value": f"{bmi} kg/m²", "status": "Normal Weight", "badge": "success"})

    if bp >= 90:
        clinical_flags.append("Stage 2 Diastolic Hypertension (>= 90 mm Hg)")
        biomarkers.append({"name": "Diastolic BP", "value": f"{bp} mm Hg", "status": "Hypertensive", "badge": "danger"})
    elif bp >= 80:
        clinical_flags.append("Stage 1 Diastolic Hypertension (80 - 89 mm Hg)")
        biomarkers.append({"name": "Diastolic BP", "value": f"{bp} mm Hg", "status": "Elevated", "badge": "warning"})
    elif bp > 0:
        biomarkers.append({"name": "Diastolic BP", "value": f"{bp} mm Hg", "status": "Optimal", "badge": "success"})

    if insulin > 166:
        biomarkers.append({"name": "Serum Insulin", "value": f"{insulin} µU/mL", "status": "Hyperinsulinemia (Insulin Resistance)", "badge": "warning"})
    elif insulin > 0:
        biomarkers.append({"name": "Serum Insulin", "value": f"{insulin} µU/mL", "status": "Normal Range", "badge": "success"})

    # Determine urgency and concrete actions
    if risk_level == "High":
        urgency = "Urgent Clinical Review (Within 7-14 Days)"
        actions.extend([
            "Schedule an immediate Glycated Hemoglobin (HbA1c) diagnostic test to assess long-term glycemic control.",
            "Consult with an endocrinologist or diabetologist for a formal diagnostic workup and medical evaluation.",
            "Perform a comprehensive fasting lipid profile (total cholesterol, HDL, LDL, triglycerides) and renal panel (eGFR, microalbuminuria).",
            "Implement continuous blood glucose monitoring (fasting and 2-hour postprandial logs).",
            "Adopt a medically supervised carbohydrate-restricted, Mediterranean-style dietary plan rich in soluble fiber."
        ])
    elif risk_level == "Moderate":
        urgency = "Proactive Preventive Assessment (Within 30 Days)"
        actions.extend([
            "Order an Oral Glucose Tolerance Test (OGTT) or HbA1c test to evaluate prediabetic condition.",
            "Engage in at least 150 minutes of moderate-intensity aerobic physical activity weekly (e.g. brisk walking, cycling).",
            "Consult a registered clinical dietitian for nutritional coaching targeting calorie deficit and low-GI foods.",
            "Monitor blood pressure and fasting glucose weekly at home.",
            "Target a 5% to 7% reduction in total body weight if BMI indicates overweight or obesity."
        ])
    else:
        urgency = "Annual Routine Health Maintenance"
        actions.extend([
            "Maintain current balanced dietary habits emphasizing whole grains, vegetables, and lean proteins.",
            "Continue regular cardiovascular exercise and muscle-strengthening activities at least 3 days per week.",
            "Schedule annual preventive metabolic health screening and lipid panels.",
            "Stay adequately hydrated, maintain healthy sleep hygiene (7-8 hours/night), and limit processed sugars."
        ])

    return {
        "disease": "Diabetes Mellitus",
        "risk_level": risk_level,
        "risk_percentage": risk_percentage,
        "urgency": urgency,
        "clinical_flags": clinical_flags,
        "biomarkers": biomarkers,
        "actions": actions,
        "disclaimer": "This AI assessment is an analytical screening tool and does not constitute a definitive medical diagnosis. Always consult certified healthcare professionals."
    }


def generate_heart_recommendations(inputs, risk_percentage, risk_level):
    """
    Generate tailored clinical recommendations based on heart disease inputs and predicted risk.
    """
    trestbps = float(inputs.get('trestbps', 0))
    chol = float(inputs.get('chol', 0))
    thalach = float(inputs.get('thalach', 0))
    oldpeak = float(inputs.get('oldpeak', 0))
    cp = int(inputs.get('cp', 0))
    exang = int(inputs.get('exang', 0))
    age = int(inputs.get('age', 0))

    biomarkers = []
    actions = []
    clinical_flags = []
    urgency = "Standard Routine"

    # Biomarker analysis
    if trestbps >= 140:
        clinical_flags.append("Stage 2 Systolic Hypertension (>= 140 mm Hg)")
        biomarkers.append({"name": "Resting BP", "value": f"{trestbps} mm Hg", "status": "Stage 2 Hypertension", "badge": "danger"})
    elif trestbps >= 130:
        clinical_flags.append("Stage 1 Systolic Hypertension (130-139 mm Hg)")
        biomarkers.append({"name": "Resting BP", "value": f"{trestbps} mm Hg", "status": "Stage 1 Hypertension", "badge": "warning"})
    elif trestbps > 0:
        biomarkers.append({"name": "Resting BP", "value": f"{trestbps} mm Hg", "status": "Normal / Prehypertensive", "badge": "success"})

    if chol >= 240:
        clinical_flags.append("Hypercholesterolemia (>= 240 mg/dL)")
        biomarkers.append({"name": "Total Cholesterol", "value": f"{chol} mg/dL", "status": "High Risk", "badge": "danger"})
    elif chol >= 200:
        clinical_flags.append("Borderline High Cholesterol (200-239 mg/dL)")
        biomarkers.append({"name": "Total Cholesterol", "value": f"{chol} mg/dL", "status": "Borderline", "badge": "warning"})
    elif chol > 0:
        biomarkers.append({"name": "Total Cholesterol", "value": f"{chol} mg/dL", "status": "Desirable (<200 mg/dL)", "badge": "success"})

    if oldpeak >= 2.0:
        clinical_flags.append("Significant ST-segment depression (> 2.0 mm) suggestive of myocardial ischemia")
        biomarkers.append({"name": "ST Depression", "value": f"{oldpeak} mm", "status": "Marked Ischemia Risk", "badge": "danger"})
    elif oldpeak > 0:
        biomarkers.append({"name": "ST Depression", "value": f"{oldpeak} mm", "status": "Mild ST Depression", "badge": "warning"})

    if exang == 1:
        clinical_flags.append("Reported Exercise-Induced Angina")

    # Recommendations based on risk
    if risk_level == "High":
        urgency = "Priority Cardiologist Referral (Immediate to 48 Hours)"
        actions.extend([
            "Urgent consultation with a board-certified Cardiologist for a 12-lead Electrocardiogram (ECG) and Transthoracic Echocardiogram (TTE).",
            "Consider a formal treadmill stress test or nuclear myocardial perfusion imaging to assess functional coronary ischemia.",
            "Comprehensive serum lipid subfraction fractionation (LDL-C, HDL-C, ApoB, Lp(a)) and high-sensitivity C-reactive protein (hs-CRP).",
            "Evaluate candidacy for cardioprotective pharmacotherapy (e.g., statin therapy, ACE inhibitors, or beta-blockers as prescribed).",
            "Strict sodium restriction (<1,500 mg/day) and adoption of the Dietary Approaches to Stop Hypertension (DASH) diet."
        ])
    elif risk_level == "Moderate":
        urgency = "Comprehensive Cardiovascular Checkup (Within 2-3 Weeks)"
        actions.extend([
            "Undergo a resting 12-lead ECG and complete fasting metabolic/cardiovascular biomarker screening.",
            "Establish structured daily ambulatory blood pressure monitoring (morning and evening logs).",
            "Initiate moderate, physician-approved aerobic exercise (e.g., 30 minutes of brisk walking 5 times weekly).",
            "Limit saturated fats, trans fats, and processed foods; increase consumption of omega-3 fatty acids and plant sterols.",
            "Cessation of smoking/tobacco products and stress reduction techniques (mindfulness, guided breathing)."
        ])
    else:
        urgency = "Routine Preventive Cardiovascular Surveillance"
        actions.extend([
            "Maintain active lifestyle with at least 150 minutes of moderate or 75 minutes of vigorous exercise weekly.",
            "Adhere to an antioxidant-rich Mediterranean dietary pattern emphasizing extra virgin olive oil, nuts, and fish.",
            "Annual preventive cardiovascular checkup including blood pressure and lipid panel reviews.",
            "Maintain optimal body weight and avoid tobacco or excessive alcohol consumption."
        ])

    return {
        "disease": "Coronary Heart Disease",
        "risk_level": risk_level,
        "risk_percentage": risk_percentage,
        "urgency": urgency,
        "clinical_flags": clinical_flags,
        "biomarkers": biomarkers,
        "actions": actions,
        "disclaimer": "This AI assessment is an analytical screening tool and does not constitute a definitive medical diagnosis. Always consult certified healthcare professionals."
    }

"""
NeuroCare Database Layer
SQLite database operations for User Management, Patient Predictions, and Dashboard Analytics.
"""

import sqlite3
import json
import os
from datetime import datetime

DATABASE_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'database.db')

def get_db_connection():
    """Establish connection to SQLite database with dictionary-like row factory."""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialise database schema with required tables and indexes."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT DEFAULT 'Medical Practitioner',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Predictions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            patient_name TEXT NOT NULL,
            patient_age INTEGER NOT NULL,
            patient_gender TEXT NOT NULL,
            disease_type TEXT NOT NULL,
            input_data TEXT NOT NULL,
            risk_probability REAL NOT NULL,
            risk_percentage REAL NOT NULL,
            risk_level TEXT NOT NULL,
            recommendations TEXT NOT NULL,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')

    # Create indexes for fast lookup
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_id ON predictions(user_id)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_disease_type ON predictions(disease_type)')
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_created_at ON predictions(created_at)')

    conn.commit()
    conn.close()

# ----------------- User Management -----------------

def create_user(username, email, password_hash, full_name, role='Medical Practitioner'):
    """Create a new user."""
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO users (username, email, password_hash, full_name, role)
            VALUES (?, ?, ?, ?, ?)
        ''', (username.strip().lower(), email.strip().lower(), password_hash, full_name.strip(), role))
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        return None
    finally:
        conn.close()

def get_user_by_username(username):
    """Retrieve user record by username."""
    conn = get_db_connection()
    user = conn.execute(
        'SELECT * FROM users WHERE LOWER(username) = ?', 
        (username.strip().lower(),)
    ).fetchone()
    conn.close()
    return user

def get_user_by_email(email):
    """Retrieve user record by email."""
    conn = get_db_connection()
    user = conn.execute(
        'SELECT * FROM users WHERE LOWER(email) = ?', 
        (email.strip().lower(),)
    ).fetchone()
    conn.close()
    return user

def get_user_by_id(user_id):
    """Retrieve user record by ID."""
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    return user

# ----------------- Patient Predictions -----------------

def save_prediction(user_id, patient_name, patient_age, patient_gender, disease_type, 
                    input_data, risk_probability, risk_percentage, risk_level, recommendations, notes=None):
    """Save a patient health assessment prediction record."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    input_str = json.dumps(input_data) if isinstance(input_data, (dict, list)) else str(input_data)
    rec_str = json.dumps(recommendations) if isinstance(recommendations, (dict, list)) else str(recommendations)
    
    cursor.execute('''
        INSERT INTO predictions (
            user_id, patient_name, patient_age, patient_gender, disease_type,
            input_data, risk_probability, risk_percentage, risk_level, recommendations, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        user_id, patient_name.strip(), patient_age, patient_gender, disease_type,
        input_str, risk_probability, risk_percentage, risk_level, rec_str, notes
    ))
    conn.commit()
    pred_id = cursor.lastrowid
    conn.close()
    return pred_id

def get_predictions(user_id=None, disease_type=None, search=None, limit=50, offset=0):
    """Retrieve prediction records with optional filtering and search."""
    conn = get_db_connection()
    query = 'SELECT * FROM predictions WHERE 1=1'
    params = []

    if user_id is not None:
        query += ' AND user_id = ?'
        params.append(user_id)

    if disease_type and disease_type != 'all':
        query += ' AND disease_type = ?'
        params.append(disease_type)

    if search:
        query += ' AND (patient_name LIKE ? OR risk_level LIKE ?)'
        params.extend([f'%{search}%', f'%{search}%'])

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
    params.extend([limit, offset])

    rows = conn.execute(query, params).fetchall()
    conn.close()
    return rows

def get_prediction_by_id(pred_id, user_id=None):
    """Retrieve a specific prediction record with JSON parsed."""
    conn = get_db_connection()
    if user_id:
        row = conn.execute('SELECT * FROM predictions WHERE id = ? AND user_id = ?', (pred_id, user_id)).fetchone()
    else:
        row = conn.execute('SELECT * FROM predictions WHERE id = ?', (pred_id,)).fetchone()
    conn.close()
    
    if not row:
        return None

    data = dict(row)
    try:
        data['input_data'] = json.loads(data['input_data'])
    except Exception:
        pass
    try:
        data['recommendations'] = json.loads(data['recommendations'])
    except Exception:
        pass
    return data

def delete_prediction(pred_id, user_id=None):
    """Delete a prediction record."""
    conn = get_db_connection()
    cursor = conn.cursor()
    if user_id:
        cursor.execute('DELETE FROM predictions WHERE id = ? AND user_id = ?', (pred_id, user_id))
    else:
        cursor.execute('DELETE FROM predictions WHERE id = ?', (pred_id,))
    deleted = cursor.rowcount > 0
    conn.commit()
    conn.close()
    return deleted

# ----------------- Dashboard Analytics -----------------

def get_dashboard_analytics(user_id=None):
    """Compute aggregate clinical analytics for the dashboard."""
    conn = get_db_connection()
    user_filter = 'WHERE user_id = ?' if user_id is not None else ''
    params = [user_id] if user_id is not None else []

    # Total predictions
    total = conn.execute(f'SELECT COUNT(*) FROM predictions {user_filter}', params).fetchone()[0]

    # Counts by disease
    d_params = [user_id, 'diabetes'] if user_id is not None else ['diabetes']
    d_filter = 'WHERE user_id = ? AND disease_type = ?' if user_id is not None else 'WHERE disease_type = ?'
    diabetes_count = conn.execute(f'SELECT COUNT(*) FROM predictions {d_filter}', d_params).fetchone()[0]

    h_params = [user_id, 'heart'] if user_id is not None else ['heart']
    h_filter = 'WHERE user_id = ? AND disease_type = ?' if user_id is not None else 'WHERE disease_type = ?'
    heart_count = conn.execute(f'SELECT COUNT(*) FROM predictions {h_filter}', h_params).fetchone()[0]

    # Risk level distribution
    high_risk_params = [user_id, 'High'] if user_id is not None else ['High']
    high_filter = 'WHERE user_id = ? AND risk_level = ?' if user_id is not None else 'WHERE risk_level = ?'
    high_risk = conn.execute(f'SELECT COUNT(*) FROM predictions {high_filter}', high_risk_params).fetchone()[0]

    mod_risk_params = [user_id, 'Moderate'] if user_id is not None else ['Moderate']
    mod_filter = 'WHERE user_id = ? AND risk_level = ?' if user_id is not None else 'WHERE risk_level = ?'
    moderate_risk = conn.execute(f'SELECT COUNT(*) FROM predictions {mod_filter}', mod_risk_params).fetchone()[0]

    low_risk_params = [user_id, 'Low'] if user_id is not None else ['Low']
    low_filter = 'WHERE user_id = ? AND risk_level = ?' if user_id is not None else 'WHERE risk_level = ?'
    low_risk = conn.execute(f'SELECT COUNT(*) FROM predictions {low_filter}', low_risk_params).fetchone()[0]

    # Recent 6 assessments
    recent = conn.execute(
        f'SELECT id, patient_name, patient_age, patient_gender, disease_type, risk_percentage, risk_level, created_at '
        f'FROM predictions {user_filter} ORDER BY created_at DESC LIMIT 6',
        params
    ).fetchall()

    # Average risk percentage
    avg_risk_row = conn.execute(f'SELECT AVG(risk_percentage) FROM predictions {user_filter}', params).fetchone()
    avg_risk = round(avg_risk_row[0], 1) if avg_risk_row and avg_risk_row[0] is not None else 0.0

    conn.close()

    return {
        'total_predictions': total,
        'diabetes_count': diabetes_count,
        'heart_count': heart_count,
        'high_risk': high_risk,
        'moderate_risk': moderate_risk,
        'low_risk': low_risk,
        'avg_risk': avg_risk,
        'recent_predictions': [dict(r) for r in recent]
    }

"""
NeuroCare Deep Learning Model Inference & Explainability Engine
Loads trained neural networks and scalers, performs feature preprocessing, computes prediction probabilities,
and determines biomarker impact factors for visual interpretability.
"""

import os
import json
import numpy as np
import joblib

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(BASE_DIR, 'models')

# Global cached singletons
_DIABETES_MODEL = None
_DIABETES_SCALER = None
_HEART_MODEL = None
_HEART_SCALER = None

def get_diabetes_assets():
    """Load and cache diabetes neural network and scaler."""
    global _DIABETES_MODEL, _DIABETES_SCALER
    model_path = os.path.join(MODELS_DIR, 'diabetes_model.keras')
    scaler_path = os.path.join(MODELS_DIR, 'diabetes_scaler.joblib')

    if _DIABETES_MODEL is None and os.path.exists(model_path):
        _DIABETES_MODEL = tf.keras.models.load_model(model_path)
    if _DIABETES_SCALER is None and os.path.exists(scaler_path):
        _DIABETES_SCALER = joblib.load(scaler_path)

    return _DIABETES_MODEL, _DIABETES_SCALER

def get_heart_assets():
    """Load and cache heart disease neural network and scaler."""
    global _HEART_MODEL, _HEART_SCALER
    model_path = os.path.join(MODELS_DIR, 'heart_model.keras')
    scaler_path = os.path.join(MODELS_DIR, 'heart_scaler.joblib')

    if _HEART_MODEL is None and os.path.exists(model_path):
        _HEART_MODEL = tf.keras.models.load_model(model_path)
    if _HEART_SCALER is None and os.path.exists(scaler_path):
        _HEART_SCALER = joblib.load(scaler_path)

    return _HEART_MODEL, _HEART_SCALER

def classify_risk_level(prob):
    """Categorize prediction probability into clinical risk strata."""
    pct = round(float(prob) * 100, 1)
    if pct < 35.0:
        return 'Low', pct
    elif pct < 65.0:
        return 'Moderate', pct
    else:
        return 'High', pct

def predict_diabetes_risk(form_data):
    """
    Execute neural network inference for Diabetes Mellitus assessment.
    """
    model, scaler = get_diabetes_assets()
    if model is None or scaler is None:
        raise RuntimeError("Diabetes model or scaler not found. Please train models first.")

    # Extract parameters
    pregnancies = float(form_data.get('pregnancies', 0))
    glucose = float(form_data.get('glucose', 0))
    blood_pressure = float(form_data.get('blood_pressure', 0))
    skin_thickness = float(form_data.get('skin_thickness', 0))
    insulin = float(form_data.get('insulin', 0))
    bmi = float(form_data.get('bmi', 0))
    dpf = float(form_data.get('dpf', 0.5))
    age = float(form_data.get('age', 30))

    features = np.array([[pregnancies, glucose, blood_pressure, skin_thickness, insulin, bmi, dpf, age]])
    features_scaled = scaler.transform(features)
    raw_pred = model.predict(features_scaled, verbose=0)
    prob = float(raw_pred.ravel()[0])
    risk_level, risk_percentage = classify_risk_level(prob)

    # Feature contribution / explainability calculation
    # Compute relative impact based on standardized deviations and clinical thresholds
    feature_impacts = [
        {"name": "Plasma Glucose", "value": f"{glucose} mg/dL", "impact": "High" if glucose > 140 else "Normal", "score": min(100, max(10, int(glucose / 200 * 100)))},
        {"name": "Body Mass Index (BMI)", "value": f"{bmi} kg/m²", "impact": "High" if bmi > 30 else ("Moderate" if bmi > 25 else "Normal"), "score": min(100, max(10, int(bmi / 40 * 100)))},
        {"name": "Diastolic Blood Pressure", "value": f"{blood_pressure} mm Hg", "impact": "High" if blood_pressure > 85 else "Normal", "score": min(100, max(10, int(blood_pressure / 110 * 100)))},
        {"name": "Serum Insulin", "value": f"{insulin} µU/mL", "impact": "Elevated" if insulin > 160 else "Normal", "score": min(100, max(10, int(insulin / 300 * 100)))},
        {"name": "Age Factor", "value": f"{int(age)} years", "impact": "Elevated" if age > 45 else "Normal", "score": min(100, max(10, int(age / 80 * 100)))},
        {"name": "Pedigree Function", "value": f"{dpf:.2f}", "impact": "Moderate" if dpf > 0.6 else "Normal", "score": min(100, max(10, int(dpf / 2.0 * 100)))}
    ]

    return {
        'risk_probability': prob,
        'risk_percentage': risk_percentage,
        'risk_level': risk_level,
        'feature_impacts': feature_impacts
    }

def predict_heart_risk(form_data):
    """
    Execute neural network inference for Cardiovascular Disease assessment.
    """
    model, scaler = get_heart_assets()
    if model is None or scaler is None:
        raise RuntimeError("Heart disease model or scaler not found. Please train models first.")

    age = float(form_data.get('age', 50))
    sex = float(form_data.get('sex', 1))
    cp = float(form_data.get('cp', 0))
    trestbps = float(form_data.get('trestbps', 120))
    chol = float(form_data.get('chol', 200))
    fbs = float(form_data.get('fbs', 0))
    restecg = float(form_data.get('restecg', 0))
    thalach = float(form_data.get('thalach', 150))
    exang = float(form_data.get('exang', 0))
    oldpeak = float(form_data.get('oldpeak', 0.0))
    slope = float(form_data.get('slope', 1))
    ca = float(form_data.get('ca', 0))
    thal = float(form_data.get('thal', 2))

    features = np.array([[age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]])
    features_scaled = scaler.transform(features)
    raw_pred = model.predict(features_scaled, verbose=0)
    prob = float(raw_pred.ravel()[0])
    risk_level, risk_percentage = classify_risk_level(prob)

    # Explainability factors
    cp_labels = ["Typical Angina", "Atypical Angina", "Non-anginal Pain", "Asymptomatic"]
    cp_label = cp_labels[int(cp)] if int(cp) < len(cp_labels) else "Normal"
    
    feature_impacts = [
        {"name": "Chest Pain Type", "value": cp_label, "impact": "Significant" if cp > 0 else "Low", "score": min(100, max(15, int((cp + 1) * 25)))},
        {"name": "ST Depression (Oldpeak)", "value": f"{oldpeak} mm", "impact": "Elevated" if oldpeak > 1.5 else "Normal", "score": min(100, max(10, int(oldpeak / 4.0 * 100)))},
        {"name": "Resting Blood Pressure", "value": f"{int(trestbps)} mm Hg", "impact": "High" if trestbps > 140 else "Normal", "score": min(100, max(15, int(trestbps / 180 * 100)))},
        {"name": "Serum Cholesterol", "value": f"{int(chol)} mg/dL", "impact": "Elevated" if chol > 240 else "Normal", "score": min(100, max(15, int(chol / 350 * 100)))},
        {"name": "Max Heart Rate (Thalach)", "value": f"{int(thalach)} bpm", "impact": "Risk Factor" if thalach < 120 else "Normal", "score": min(100, max(10, int((200 - thalach) / 120 * 100)))},
        {"name": "Fluoroscopy Vessels (CA)", "value": f"{int(ca)} vessels", "impact": "High Risk" if ca > 0 else "Normal", "score": min(100, max(10, int((ca + 1) * 25)))}
    ]

    return {
        'risk_probability': prob,
        'risk_percentage': risk_percentage,
        'risk_level': risk_level,
        'feature_impacts': feature_impacts
    }

def get_model_evaluation_metrics(disease_type='diabetes'):
    """Retrieve saved model evaluation metrics and training history."""
    filename = 'diabetes_metrics.json' if disease_type == 'diabetes' else 'heart_metrics.json'
    metrics_path = os.path.join(MODELS_DIR, filename)
    if os.path.exists(metrics_path):
        with open(metrics_path, 'r') as f:
            return json.load(f)
    return None

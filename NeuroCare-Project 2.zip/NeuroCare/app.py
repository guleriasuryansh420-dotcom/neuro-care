"""
NeuroCare – AI-Based Disease Prediction & Health Intelligence System
Main Flask Application
"""

import os
import json
from functools import wraps
from datetime import datetime

from flask import (
    Flask, render_template, request, redirect, url_for, 
    flash, session, jsonify, abort
)
from werkzeug.security import generate_password_hash, check_password_hash

from utils.db import (
    init_db, create_user, get_user_by_username, get_user_by_email, get_user_by_id,
    save_prediction, get_predictions, get_prediction_by_id, delete_prediction,
    get_dashboard_analytics, get_db_connection
)
from utils.model_utils import (
    predict_diabetes_risk, predict_heart_risk, get_model_evaluation_metrics
)
from utils.recommendations import (
    generate_diabetes_recommendations, generate_heart_recommendations
)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'neurocare-medical-ai-secret-key-2026')
app.config['PERMANENT_SESSION_LIFETIME'] = 86400  # 24 hours

# ---------------------------------------------------------
# AUTHENTICATION DECORATOR & CONTEXT PROCESSORS
# ---------------------------------------------------------

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please authenticate to access the NeuroCare Clinical Portal.', 'warning')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@app.context_processor
def inject_user():
    user = None
    if 'user_id' in session:
        user = get_user_by_id(session['user_id'])
    return dict(current_user=user, current_year=datetime.now().year)

# ---------------------------------------------------------
# CORE ROUTES
# ---------------------------------------------------------

@app.route('/')
def index():
    """Modern Landing Page introducing NeuroCare."""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User authentication."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip().lower()
        password = request.form.get('password', '')

        if not username or not password:
            flash('Please enter both username and password.', 'danger')
            return render_template('login.html')

        user = get_user_by_username(username)
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['full_name'] = user['full_name']
            session['role'] = user['role']
            flash(f'Welcome back, Dr. {user["full_name"]}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Invalid username or password credentials.', 'danger')

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Practitioner Registration."""
    if 'user_id' in session:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        username = request.form.get('username', '').strip().lower()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        role = request.form.get('role', 'Medical Practitioner')

        if not full_name or not username or not email or not password:
            flash('All fields are required.', 'danger')
            return render_template('register.html')

        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('register.html')

        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('register.html')

        if get_user_by_username(username):
            flash('Username is already registered.', 'danger')
            return render_template('register.html')

        if get_user_by_email(email):
            flash('Email address is already registered.', 'danger')
            return render_template('register.html')

        password_hash = generate_password_hash(password, method='pbkdf2:sha256')
        user_id = create_user(username, email, password_hash, full_name, role)

        if user_id:
            session['user_id'] = user_id
            session['username'] = username
            session['full_name'] = full_name
            session['role'] = role
            flash('Registration successful! Welcome to the NeuroCare System.', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Registration failed due to a database error.', 'danger')

    return render_template('register.html')

@app.route('/logout')
def logout():
    """Practitioner Logout."""
    session.clear()
    flash('You have been securely signed out.', 'info')
    return redirect(url_for('login'))

# ---------------------------------------------------------
# DASHBOARD & ANALYTICS
# ---------------------------------------------------------

@app.route('/dashboard')
@login_required
def dashboard():
    """Main health intelligence dashboard."""
    stats = get_dashboard_analytics()
    return render_template('dashboard.html', stats=stats)

@app.route('/analytics')
@login_required
def analytics():
    """Model evaluation metrics and training dynamics."""
    disease = request.args.get('disease', 'diabetes')
    if disease not in ['diabetes', 'heart']:
        disease = 'diabetes'
    
    metrics = get_model_evaluation_metrics(disease)
    return render_template('analytics.html', disease=disease, metrics=metrics)

@app.route('/about')
def about():
    """Academic and technical research documentation."""
    return render_template('about.html')

# ---------------------------------------------------------
# PREDICTION WORKFLOWS
# ---------------------------------------------------------

@app.route('/predict/diabetes', methods=['GET', 'POST'])
@login_required
def predict_diabetes():
    """Interactive Diabetes Mellitus Risk Prediction."""
    if request.method == 'POST':
        try:
            patient_name = request.form.get('patient_name', '').strip()
            patient_age = int(request.form.get('age', 0))
            patient_gender = request.form.get('gender', 'Female')

            if not patient_name or patient_age <= 0:
                flash('Please provide valid patient identification and age.', 'danger')
                return render_template('predict_diabetes.html')

            form_data = {
                'pregnancies': float(request.form.get('pregnancies', 0)),
                'glucose': float(request.form.get('glucose', 0)),
                'blood_pressure': float(request.form.get('blood_pressure', 0)),
                'skin_thickness': float(request.form.get('skin_thickness', 0)),
                'insulin': float(request.form.get('insulin', 0)),
                'bmi': float(request.form.get('bmi', 0)),
                'dpf': float(request.form.get('dpf', 0.5)),
                'age': patient_age
            }

            # Run ANN prediction
            prediction_output = predict_diabetes_risk(form_data)
            risk_prob = prediction_output['risk_probability']
            risk_pct = prediction_output['risk_percentage']
            risk_lvl = prediction_output['risk_level']
            feature_impacts = prediction_output['feature_impacts']

            # Generate clinical recommendations
            recommendations = generate_diabetes_recommendations(form_data, risk_pct, risk_lvl)
            recommendations['feature_impacts'] = feature_impacts

            # Save in database
            pred_id = save_prediction(
                user_id=session['user_id'],
                patient_name=patient_name,
                patient_age=patient_age,
                patient_gender=patient_gender,
                disease_type='diabetes',
                input_data=form_data,
                risk_probability=risk_prob,
                risk_percentage=risk_pct,
                risk_level=risk_lvl,
                recommendations=recommendations,
                notes=request.form.get('notes', '')
            )

            flash('Neural network assessment generated successfully.', 'success')
            return redirect(url_for('prediction_result', prediction_id=pred_id))

        except Exception as e:
            flash(f'Prediction error: {str(e)}', 'danger')
            return render_template('predict_diabetes.html')

    return render_template('predict_diabetes.html')

@app.route('/predict/heart', methods=['GET', 'POST'])
@login_required
def predict_heart():
    """Interactive Heart Disease Risk Prediction."""
    if request.method == 'POST':
        try:
            patient_name = request.form.get('patient_name', '').strip()
            patient_age = int(request.form.get('age', 0))
            patient_gender = request.form.get('gender', 'Male')

            if not patient_name or patient_age <= 0:
                flash('Please provide valid patient identification and age.', 'danger')
                return render_template('predict_heart.html')

            sex_val = 1 if patient_gender.lower() == 'male' else 0

            form_data = {
                'age': patient_age,
                'sex': sex_val,
                'cp': int(request.form.get('cp', 0)),
                'trestbps': float(request.form.get('trestbps', 120)),
                'chol': float(request.form.get('chol', 200)),
                'fbs': int(request.form.get('fbs', 0)),
                'restecg': int(request.form.get('restecg', 0)),
                'thalach': float(request.form.get('thalach', 150)),
                'exang': int(request.form.get('exang', 0)),
                'oldpeak': float(request.form.get('oldpeak', 0.0)),
                'slope': int(request.form.get('slope', 1)),
                'ca': int(request.form.get('ca', 0)),
                'thal': int(request.form.get('thal', 2))
            }

            # Run ANN prediction
            prediction_output = predict_heart_risk(form_data)
            risk_prob = prediction_output['risk_probability']
            risk_pct = prediction_output['risk_percentage']
            risk_lvl = prediction_output['risk_level']
            feature_impacts = prediction_output['feature_impacts']

            # Generate clinical recommendations
            recommendations = generate_heart_recommendations(form_data, risk_pct, risk_lvl)
            recommendations['feature_impacts'] = feature_impacts

            # Save in database
            pred_id = save_prediction(
                user_id=session['user_id'],
                patient_name=patient_name,
                patient_age=patient_age,
                patient_gender=patient_gender,
                disease_type='heart',
                input_data=form_data,
                risk_probability=risk_prob,
                risk_percentage=risk_pct,
                risk_level=risk_lvl,
                recommendations=recommendations,
                notes=request.form.get('notes', '')
            )

            flash('Neural network assessment generated successfully.', 'success')
            return redirect(url_for('prediction_result', prediction_id=pred_id))

        except Exception as e:
            flash(f'Prediction error: {str(e)}', 'danger')
            return render_template('predict_heart.html')

    return render_template('predict_heart.html')

@app.route('/result/<int:prediction_id>')
@login_required
def prediction_result(prediction_id):
    """View detailed prediction report and clinical recommendations."""
    pred = get_prediction_by_id(prediction_id)
    if not pred:
        flash('Assessment record not found.', 'danger')
        return redirect(url_for('dashboard'))

    return render_template('result.html', prediction=pred)

@app.route('/history')
@login_required
def history():
    """View historical patient assessments."""
    disease = request.args.get('disease', 'all')
    search = request.args.get('search', '').strip()
    predictions = get_predictions(disease_type=disease, search=search, limit=100)
    return render_template('history.html', predictions=predictions, selected_disease=disease, search_query=search)

@app.route('/history/delete/<int:prediction_id>', methods=['POST'])
@login_required
def delete_history_item(prediction_id):
    """Delete a patient prediction record."""
    success = delete_prediction(prediction_id)
    if success:
        flash('Patient assessment record removed.', 'info')
    else:
        flash('Failed to delete record.', 'danger')
    return redirect(url_for('history'))

# ---------------------------------------------------------
# API ENDPOINTS FOR CHARTS & ASYNC DATA
# ---------------------------------------------------------

@app.route('/api/metrics/<disease_type>')
def api_metrics(disease_type):
    """Return model evaluation metrics in JSON for interactive Chart.js graphs."""
    metrics = get_model_evaluation_metrics(disease_type)
    if not metrics:
        return jsonify({'error': 'Metrics not found'}), 404
    return jsonify(metrics)

@app.route('/api/dashboard-stats')
@login_required
def api_dashboard_stats():
    """Return current dashboard stats."""
    stats = get_dashboard_analytics()
    return jsonify(stats)

# ---------------------------------------------------------
# ERROR HANDLERS
# ---------------------------------------------------------

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

# ---------------------------------------------------------
# INITIALIZATION & SEEDING
# ---------------------------------------------------------

def seed_default_data():
    """Seed initial practitioner and sample clinical records for review."""
    init_db()
    # Check if admin clinician exists
    clinician = get_user_by_username('doctor')
    if not clinician:
        pwd_hash = generate_password_hash('neurocare123', method='pbkdf2:sha256')
        uid = create_user(
            username='doctor',
            email='dr.alex@neurocare.ai',
            password_hash=pwd_hash,
            full_name='Alex Carter, MD',
            role='Chief Medical Officer'
        )
        print("[DB Seed] Created default clinician account: doctor / neurocare123")

        # Seed sample assessments
        sample_diabetes_data = {
            'pregnancies': 2, 'glucose': 158.0, 'blood_pressure': 84.0,
            'skin_thickness': 32.0, 'insulin': 175.0, 'bmi': 33.4,
            'dpf': 0.65, 'age': 48
        }
        recs_d = generate_diabetes_recommendations(sample_diabetes_data, 78.4, 'High')
        recs_d['feature_impacts'] = [
            {"name": "Plasma Glucose", "value": "158 mg/dL", "impact": "High", "score": 79},
            {"name": "Body Mass Index", "value": "33.4 kg/m²", "impact": "High", "score": 83},
            {"name": "Diastolic BP", "value": "84 mm Hg", "impact": "Normal", "score": 60}
        ]
        save_prediction(
            user_id=uid,
            patient_name='Eleanor Vance',
            patient_age=48,
            patient_gender='Female',
            disease_type='diabetes',
            input_data=sample_diabetes_data,
            risk_probability=0.784,
            risk_percentage=78.4,
            risk_level='High',
            recommendations=recs_d,
            notes='Patient exhibits marked post-prandial hyperglycemia and elevated BMI.'
        )

        sample_heart_data = {
            'age': 57, 'sex': 1, 'cp': 2, 'trestbps': 142.0, 'chol': 265.0,
            'fbs': 1, 'restecg': 1, 'thalach': 138.0, 'exang': 1, 'oldpeak': 2.3,
            'slope': 1, 'ca': 1, 'thal': 2
        }
        recs_h = generate_heart_recommendations(sample_heart_data, 82.5, 'High')
        recs_h['feature_impacts'] = [
            {"name": "ST Depression", "value": "2.3 mm", "impact": "Elevated", "score": 85},
            {"name": "Serum Cholesterol", "value": "265 mg/dL", "impact": "Elevated", "score": 80},
            {"name": "Resting BP", "value": "142 mm Hg", "impact": "High", "score": 75}
        ]
        save_prediction(
            user_id=uid,
            patient_name='Arthur Pendelton',
            patient_age=57,
            patient_gender='Male',
            disease_type='heart',
            input_data=sample_heart_data,
            risk_probability=0.825,
            risk_percentage=82.5,
            risk_level='High',
            recommendations=recs_h,
            notes='Moderate exertion induced angina; ECG indicates ST depression.'
        )

        # A low-risk patient
        low_diabetes_data = {
            'pregnancies': 0, 'glucose': 92.0, 'blood_pressure': 72.0,
            'skin_thickness': 20.0, 'insulin': 45.0, 'bmi': 22.1,
            'dpf': 0.28, 'age': 28
        }
        recs_low = generate_diabetes_recommendations(low_diabetes_data, 12.3, 'Low')
        save_prediction(
            user_id=uid,
            patient_name='Sophia Chen',
            patient_age=28,
            patient_gender='Female',
            disease_type='diabetes',
            input_data=low_diabetes_data,
            risk_probability=0.123,
            risk_percentage=12.3,
            risk_level='Low',
            recommendations=recs_low,
            notes='Routine preventive screening; optimal biomarker profiles.'
        )

if __name__ == '__main__':
    seed_default_data()
    port = int(os.environ.get('PORT', 5050))
    print(f"[NeuroCare Server] Starting application on http://127.0.0.1:{port}")
    app.run(host='0.0.0.0', port=port, debug=True)

"""
NeuroCare Automated System Verification & Test Suite
Executes integration tests on all routes, authentication, neural inference, and database persistence.
"""

import unittest
import json
from app import app
from utils.db import init_db, get_prediction_by_id

class NeuroCareTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        cls.client = app.test_client()
        init_db()

    def login_clinician(self):
        """Helper to log in default test clinician."""
        return self.client.post('/login', data={
            'username': 'doctor',
            'password': 'neurocare123'
        }, follow_redirects=True)

    def test_01_landing_page(self):
        """Test home landing page rendering."""
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'NeuroCare', res.data)
        self.assertIn(b'Artificial Neural Networks', res.data)

    def test_02_about_page(self):
        """Test academic and technical documentation page."""
        res = self.client.get('/about')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Deep Learning Architecture', res.data)
        self.assertIn(b'Pima Indians', res.data)
        self.assertIn(b'Cleveland Heart', res.data)

    def test_03_auth_protection(self):
        """Verify protected routes redirect unauthorized users to login."""
        res = self.client.get('/dashboard')
        self.assertEqual(res.status_code, 302)
        self.assertIn('/login', res.headers['Location'])

    def test_04_successful_login(self):
        """Verify successful clinician sign in."""
        res = self.login_clinician()
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Health Intelligence Dashboard', res.data)
        self.assertIn(b'Dr. Alex Carter', res.data)

    def test_05_diabetes_prediction_workflow(self):
        """Test diabetes patient submission, neural inference, and database saving."""
        self.login_clinician()
        post_data = {
            'patient_name': 'Automated Test Patient - Diabetes',
            'age': 44,
            'gender': 'Female',
            'pregnancies': 3,
            'glucose': 168.0,
            'blood_pressure': 84.0,
            'skin_thickness': 30.0,
            'insulin': 190.0,
            'bmi': 34.2,
            'dpf': 0.72,
            'notes': 'Automated test suite submission.'
        }
        res = self.client.post('/predict/diabetes', data=post_data, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Clinical Neural Assessment Report', res.data)
        self.assertIn(b'Automated Test Patient - Diabetes', res.data)
        self.assertIn(b'Biomarker Impact', res.data)

    def test_06_heart_prediction_workflow(self):
        """Test heart disease patient submission, neural inference, and database saving."""
        self.login_clinician()
        post_data = {
            'patient_name': 'Automated Test Patient - Cardiac',
            'age': 61,
            'gender': 'Male',
            'cp': 2,
            'trestbps': 155.0,
            'chol': 270.0,
            'fbs': 1,
            'restecg': 1,
            'thalach': 128.0,
            'exang': 1,
            'oldpeak': 2.4,
            'slope': 1,
            'ca': 2,
            'thal': 3,
            'notes': 'Automated test suite cardiac submission.'
        }
        res = self.client.post('/predict/heart', data=post_data, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Clinical Neural Assessment Report', res.data)
        self.assertIn(b'Automated Test Patient - Cardiac', res.data)

    def test_07_patient_history_and_search(self):
        """Test viewing history records and searching."""
        self.login_clinician()
        res = self.client.get('/history?search=Automated')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Automated Test Patient', res.data)

    def test_08_model_analytics_page(self):
        """Test model analytics and evaluation curves."""
        self.login_clinician()
        # Diabetes analytics
        res_d = self.client.get('/analytics?disease=diabetes')
        self.assertEqual(res_d.status_code, 200)
        self.assertIn(b'Empirical Confusion Matrix', res_d.data)
        self.assertIn(b'Training & Validation Loss Convergence', res_d.data)

        # Heart analytics
        res_h = self.client.get('/analytics?disease=heart')
        self.assertEqual(res_h.status_code, 200)
        self.assertIn(b'Cardiovascular Risk Neural Network', res_h.data)

    def test_09_api_endpoints(self):
        """Verify API endpoints return valid JSON metrics."""
        self.login_clinician()
        res = self.client.get('/api/metrics/diabetes')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertIn('accuracy', data)
        self.assertIn('confusion_matrix', data)
        self.assertIn('history', data)

        res_stats = self.client.get('/api/dashboard-stats')
        self.assertEqual(res_stats.status_code, 200)
        stats = json.loads(res_stats.data)
        self.assertIn('total_predictions', stats)

if __name__ == '__main__':
    unittest.main()

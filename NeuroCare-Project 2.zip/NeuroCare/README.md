# NeuroCare – AI-Based Disease Prediction & Health Intelligence System

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org/)
[![Flask](https://img.shields.io/badge/Flask-3.1-000000?style=for-the-badge&logo=flask&logoColor=white)](https://flask.palletsprojects.com/)
[![TensorFlow](https://img.shields.io/badge/TensorFlow-2.20-FF6F00?style=for-the-badge&logo=tensorflow&logoColor=white)](https://www.tensorflow.org/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.6-F7931E?style=for-the-badge&logo=scikitlearn&logoColor=white)](https://scikit-learn.org/)
[![Bootstrap](https://img.shields.io/badge/Bootstrap-5.3-7952B3?style=for-the-badge&logo=bootstrap&logoColor=white)](https://getbootstrap.com/)
[![Chart.js](https://img.shields.io/badge/Chart.js-4.4-FF6384?style=for-the-badge&logo=chartdotjs&logoColor=white)](https://www.chartjs.org/)

**NeuroCare** is a clinical-grade AI healthcare platform utilizing Deep Learning Artificial Neural Networks (Multi-Layer Perceptrons) to analyze complex patient biomarkers and predict early-stage disease risks for **Type 2 Diabetes Mellitus** and **Cardiovascular Coronary Disease**.

---

## 🌟 Key Features

1. **Dual Artificial Neural Network (ANN) Modules**:
   - **Diabetes Mellitus Model**: Multi-Layer Perceptron trained on the Pima Indians Diabetes Dataset (Glucose, Blood Pressure, BMI, Insulin, Age, Skin Thickness, Pedigree Function).
   - **Cardiovascular Disease Model**: Deep Neural Network trained on the UCI Cleveland Heart Disease Dataset (Resting BP, Cholesterol, Max Heart Rate, Chest Pain, ST Depression, Fluoroscopy Vessels).
2. **Explainable AI (XAI) & Biomarker Attribution**:
   - Displays exact risk percentage & calibrated clinical risk stratum (*Low*, *Moderate*, *High*).
   - Breakdown of specific patient biomarkers elevating risk with normal clinical baseline indicators.
3. **Automated Clinical Recommendations**:
   - Dynamic clinical guidance derived from American Diabetes Association (ADA) and American Heart Association (AHA) protocols.
   - Recommended diagnostic workups (HbA1c, fasting lipids, 12-lead ECG, stress echocardiography).
   - Urgent follow-up timelines and lifestyle/nutrition guidelines.
4. **Interactive Model Analytics Dashboard**:
   - Real-time empirical evaluation metrics: **Accuracy, Precision, Recall, F1 Score**.
   - **2x2 Empirical Confusion Matrix** (TN, FP, FN, TP).
   - Interactive **Training vs. Validation Loss Graph** across epochs.
   - Interactive **Training vs. Validation Accuracy Graph** across epochs.
5. **Patient Record History & SQLite Persistence**:
   - Historical archive of all predictions with search by patient name and disease filters.
   - Report viewing and one-click PDF printing.
6. **Modern Medical UI/UX Design**:
   - Navy Blue (`#0A192F`), Clean White, and Vibrant Cyan (`#00F2FE`) aesthetic.
   - Glassmorphism cards, responsive sidebar, animated risk gauges, and mobile responsiveness.

---

## 🏗️ Project Architecture & Structure

```
NeuroCare/
├── app.py                      # Core Flask Application & API Routes
├── train_models.py             # ANN Training Pipeline & Model Serialization
├── test_app.py                 # Automated Integration Test Suite
├── requirements.txt            # Python Dependencies
├── README.md                   # System Documentation
├── database.db                 # SQLite Database (Auto-initialized)
├── models/                     # Saved Keras Models & Scalers
│   ├── diabetes_model.keras    # Trained Diabetes MLP
│   ├── diabetes_scaler.joblib   # Fitted StandardScaler
│   ├── diabetes_metrics.json   # Accuracy, Loss Curves, Confusion Matrix
│   ├── heart_model.keras       # Trained Cardiovascular ANN
│   ├── heart_scaler.joblib      # Fitted StandardScaler
│   └── heart_metrics.json      # Accuracy, Loss Curves, Confusion Matrix
├── datasets/                   # Benchmark Medical Datasets
│   ├── diabetes.csv            # Pima Indians Diabetes Dataset (768 rows)
│   └── heart.csv               # UCI Cleveland Heart Disease Dataset (303 rows)
├── templates/                  # Jinja2 HTML5 Templates
│   ├── base.html               # Master Layout & Sidebar Navigation
│   ├── index.html              # Modern Hero Landing Page
│   ├── login.html              # Practitioner Sign-In
│   ├── register.html           # Practitioner Registration
│   ├── dashboard.html          # Clinical Health Analytics Dashboard
│   ├── predict_diabetes.html   # Diabetes Patient Input Form
│   ├── predict_heart.html      # Heart Disease Patient Input Form
│   ├── result.html             # Patient Assessment Report & Risk Gauge
│   ├── history.html            # Patient Screening History & Filter
│   ├── analytics.html          # Deep Learning Model Performance Curves
│   ├── about.html              # Academic Research Documentation Paper
│   ├── 404.html                # Error Page
│   └── 500.html                # Error Page
├── static/
│   ├── css/
│   │   └── style.css           # Custom Navy/Cyan Medical Design System
│   ├── js/
│   │   ├── main.js             # UI Logic, Sample Pre-fill, PDF Export
│   │   └── charts.js           # Chart.js Dashboard & Epoch Visualizers
│   └── images/
│       └── logo.svg            # NeuroCare Neural Shield Logo
└── utils/
    ├── __init__.py
    ├── db.py                   # SQLite Schema & CRUD Operations
    ├── model_utils.py          # Keras Model Loader & Inference Engine
    └── recommendations.py      # Clinical Action Plan & Guidance Rules
```

---

## 🧠 Deep Learning Architecture Specification

| Component | Diabetes Neural Network (MLP) | Cardiovascular Neural Network (ANN) |
|---|---|---|
| **Input Shape** | 8 Standardized Features | 13 Standardized Features |
| **Hidden Layer 1** | Dense(64, ReLU, L2=0.001) | Dense(64, ReLU, L2=0.001) |
| **Normalization 1**| BatchNormalization | BatchNormalization |
| **Dropout 1** | Dropout(rate=0.25) | Dropout(rate=0.25) |
| **Hidden Layer 2** | Dense(32, ReLU, L2=0.001) | Dense(32, ReLU, L2=0.001) |
| **Normalization 2**| BatchNormalization | BatchNormalization |
| **Dropout 2** | Dropout(rate=0.20) | Dropout(rate=0.20) |
| **Hidden Layer 3** | Dense(16, ReLU) | Dense(16, ReLU) |
| **Output Layer** | Dense(1, Sigmoid) | Dense(1, Sigmoid) |
| **Optimizer** | Adam (lr = 0.001) | Adam (lr = 0.001) |
| **Loss Function** | Binary Cross-Entropy | Binary Cross-Entropy |
| **Callbacks** | EarlyStopping (patience=25) | EarlyStopping (patience=25) |

---

## 🚀 Step-by-Step Setup & Execution Instructions (macOS)

### 1. Open Terminal and Navigate to Project Directory
```bash
cd /Users/aryan/.gemini/antigravity/scratch/NeuroCare
```

### 2. Activate the Pre-Configured Virtual Environment
```bash
source venv/bin/activate
```

*(If creating a fresh virtual environment from scratch on another system)*:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. (Optional) Retrain Deep Learning Models
The pre-trained models and metrics are already generated in `models/`. To retrain fresh neural networks on the datasets:
```bash
python train_models.py
```

### 4. Run the Automated Verification Test Suite
```bash
python test_app.py
```
*(All 9 integration tests should report `OK`)*.

### 5. Start the NeuroCare Clinical Web Application
```bash
python app.py
```

### 6. Open the Application in Your Web Browser
Navigate to:
```
http://127.0.0.1:5050
```
*(Port 5050 is configured by default to avoid macOS's native AirPlay Receiver which occupies port 5000).*

---

## 🔑 Default Clinician Reviewer Credentials

For quick evaluation, an initial clinician account is automatically seeded in the database:

| Parameter | Value |
|---|---|
| **Username** | `doctor` |
| **Password** | `neurocare123` |
| **Role** | Chief Medical Officer |

*(You can also click the **"Fill Demo"** button on the `/login` page to auto-fill these credentials with 1 click).*

---

## 🧪 Testing Patient Assessments

On both the **Diabetes Assessment** (`/predict/diabetes`) and **Cardiovascular AI** (`/predict/heart`) pages, quick sample buttons are provided at the top right:
- **High Risk Sample**: Populates biomarkers of an advanced pathological profile.
- **Borderline Sample**: Populates borderline biomarkers.
- **Normal Sample**: Populates healthy physiological baseline parameters.

Clicking **"Execute Neural Network Prediction"** will run inference through the trained Keras model, save the record to SQLite, and display the animated risk gauge with personalized clinical guidance.

---

## 📊 Model Analytics & Academic Documentation

- **Model Analytics (`/analytics`)**: View real test accuracy, precision, recall, F1 score, 2x2 confusion matrix, and interactive Chart.js loss/accuracy training curves across all epochs.
- **Academic Research (`/about`)**: Complete 11-section research documentation covering Introduction, Problem Statement, Objectives, Literature Review, ANN & Deep Learning Theory, Architecture, Datasets, Preprocessing, Evaluation, Limitations, and Future Scope.

---

*NeuroCare &copy; 2026 &bull; Developed for Clinical AI & Deep Learning Healthcare Research*

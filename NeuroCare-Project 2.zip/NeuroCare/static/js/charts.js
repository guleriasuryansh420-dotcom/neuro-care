/**
 * NeuroCare – Interactive Healthcare Chart.js Visualizations
 */

// Global Chart defaults for NeuroCare Navy/Cyan aesthetic
if (window.Chart) {
  Chart.defaults.color = '#94a3b8';
  Chart.defaults.font.family = "'Inter', sans-serif";
  Chart.defaults.plugins.tooltip.backgroundColor = '#0b1523';
  Chart.defaults.plugins.tooltip.titleColor = '#ffffff';
  Chart.defaults.plugins.tooltip.bodyColor = '#00f2fe';
  Chart.defaults.plugins.tooltip.borderColor = '#334155';
  Chart.defaults.plugins.tooltip.borderWidth = 1;
  Chart.defaults.plugins.tooltip.padding = 10;
  Chart.defaults.plugins.tooltip.cornerRadius = 8;
}

/**
 * Initialize Dashboard Analytics Charts
 */
function initDashboardCharts(stats) {
  // 1. Disease Distribution Doughnut
  const diseaseCtx = document.getElementById('diseaseDistChart');
  if (diseaseCtx) {
    new Chart(diseaseCtx, {
      type: 'doughnut',
      data: {
        labels: ['Diabetes Assessments', 'Cardiovascular Assessments'],
        datasets: [{
          data: [stats.diabetes_count || 0, stats.heart_count || 0],
          backgroundColor: ['#06b6d4', '#3b82f6'],
          borderColor: '#0f172a',
          borderWidth: 3,
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: { boxWidth: 14, padding: 16 }
          }
        },
        cutout: '72%'
      }
    });
  }

  // 2. Risk Stratification Bar Chart
  const riskCtx = document.getElementById('riskStratChart');
  if (riskCtx) {
    new Chart(riskCtx, {
      type: 'bar',
      data: {
        labels: ['Low Risk', 'Moderate Risk', 'High Risk'],
        datasets: [{
          label: 'Patients',
          data: [stats.low_risk || 0, stats.moderate_risk || 0, stats.high_risk || 0],
          backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
          borderRadius: 8,
          borderSkipped: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            ticks: { precision: 0 },
            grid: { color: 'rgba(255, 255, 255, 0.05)' }
          },
          x: {
            grid: { display: false }
          }
        },
        plugins: {
          legend: { display: false }
        }
      }
    });
  }
}

/**
 * Initialize Model Evaluation Analytics Charts (Loss & Accuracy epoch curves)
 */
function initModelAnalyticsCharts(metrics) {
  if (!metrics || !metrics.history) return;

  const history = metrics.history;
  const epochs = history.epochs || [];

  // 1. Training & Validation Loss Graph
  const lossCtx = document.getElementById('lossCurveChart');
  if (lossCtx) {
    new Chart(lossCtx, {
      type: 'line',
      data: {
        labels: epochs,
        datasets: [
          {
            label: 'Training Loss',
            data: history.train_loss,
            borderColor: '#06b6d4',
            backgroundColor: 'rgba(6, 182, 212, 0.12)',
            fill: true,
            tension: 0.3,
            pointRadius: 2,
            borderWidth: 2
          },
          {
            label: 'Validation Loss',
            data: history.val_loss,
            borderColor: '#ef4444',
            backgroundColor: 'transparent',
            borderDash: [5, 5],
            tension: 0.3,
            pointRadius: 2,
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        scales: {
          x: {
            title: { display: true, text: 'Training Epoch', color: '#64748b' },
            grid: { color: 'rgba(255, 255, 255, 0.04)' }
          },
          y: {
            title: { display: true, text: 'Binary Cross-Entropy Loss', color: '#64748b' },
            grid: { color: 'rgba(255, 255, 255, 0.06)' }
          }
        },
        plugins: {
          legend: { position: 'top', labels: { boxWidth: 14, padding: 12 } }
        }
      }
    });
  }

  // 2. Training & Validation Accuracy Graph
  const accCtx = document.getElementById('accuracyCurveChart');
  if (accCtx) {
    new Chart(accCtx, {
      type: 'line',
      data: {
        labels: epochs,
        datasets: [
          {
            label: 'Training Accuracy (%)',
            data: history.train_acc,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.12)',
            fill: true,
            tension: 0.3,
            pointRadius: 2,
            borderWidth: 2
          },
          {
            label: 'Validation Accuracy (%)',
            data: history.val_acc,
            borderColor: '#38bdf8',
            backgroundColor: 'transparent',
            borderDash: [5, 5],
            tension: 0.3,
            pointRadius: 2,
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        scales: {
          x: {
            title: { display: true, text: 'Training Epoch', color: '#64748b' },
            grid: { color: 'rgba(255, 255, 255, 0.04)' }
          },
          y: {
            title: { display: true, text: 'Accuracy (%)', color: '#64748b' },
            min: Math.max(0, Math.min(...history.train_acc, ...history.val_acc) - 10),
            max: 100,
            grid: { color: 'rgba(255, 255, 255, 0.06)' }
          }
        },
        plugins: {
          legend: { position: 'top', labels: { boxWidth: 14, padding: 12 } }
        }
      }
    });
  }
}

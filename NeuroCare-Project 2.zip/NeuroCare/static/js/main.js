/**
 * NeuroCare – Client-side interactions & utilities
 */

document.addEventListener('DOMContentLoaded', () => {
  // Mobile sidebar toggle
  const sidebarToggle = document.getElementById('sidebarToggle');
  const appSidebar = document.querySelector('.app-sidebar');

  if (sidebarToggle && appSidebar) {
    sidebarToggle.addEventListener('click', () => {
      appSidebar.classList.toggle('show');
    });

    // Close when clicking outside on mobile
    document.addEventListener('click', (e) => {
      if (window.innerWidth <= 992 && 
          !appSidebar.contains(e.target) && 
          !sidebarToggle.contains(e.target) && 
          appSidebar.classList.contains('show')) {
        appSidebar.classList.remove('show');
      }
    });
  }

  // Auto-dismiss alerts after 5 seconds
  const alerts = document.querySelectorAll('.alert-dismissible');
  alerts.forEach(alert => {
    setTimeout(() => {
      const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
      if (bsAlert) bsAlert.close();
    }, 5000);
  });
});

/**
 * Pre-fill sample patient data for testing / evaluation
 */
function fillSampleDiabetes(type) {
  const samples = {
    high: {
      patient_name: "Sarah Jenkins (High Risk Test)",
      age: 52,
      gender: "Female",
      pregnancies: 4,
      glucose: 175,
      blood_pressure: 88,
      skin_thickness: 34,
      insulin: 210,
      bmi: 35.6,
      dpf: 0.78,
      notes: "Family history of Type 2 diabetes. Persistent fatigue and polyuria reported."
    },
    normal: {
      patient_name: "Emily Watson (Normal Test)",
      age: 29,
      gender: "Female",
      pregnancies: 1,
      glucose: 94,
      blood_pressure: 72,
      skin_thickness: 22,
      insulin: 60,
      bmi: 22.4,
      dpf: 0.25,
      notes: "Annual preventive physical examination. Patient exercises regularly."
    },
    borderline: {
      patient_name: "Maria Gonzales (Borderline Test)",
      age: 41,
      gender: "Female",
      pregnancies: 2,
      glucose: 135,
      blood_pressure: 82,
      skin_thickness: 28,
      insulin: 130,
      bmi: 27.8,
      dpf: 0.52,
      notes: "Impaired fasting glucose observed in prior checkup."
    }
  };

  const data = samples[type];
  if (!data) return;

  for (const [key, value] of Object.entries(data)) {
    const el = document.getElementById(key);
    if (el) {
      el.value = value;
      // Trigger change event if needed
      el.dispatchEvent(new Event('change'));
    }
  }
}

function fillSampleHeart(type) {
  const samples = {
    high: {
      patient_name: "Marcus Vance (High Risk Test)",
      age: 63,
      gender: "Male",
      cp: 2,
      trestbps: 160,
      chol: 285,
      fbs: 1,
      restecg: 1,
      thalach: 122,
      exang: 1,
      oldpeak: 2.6,
      slope: 1,
      ca: 2,
      thal: 3,
      notes: "Patient experiences angina upon climbing stairs. History of hypertension."
    },
    normal: {
      patient_name: "David Miller (Normal Test)",
      age: 38,
      gender: "Male",
      cp: 0,
      trestbps: 118,
      chol: 182,
      fbs: 0,
      restecg: 0,
      thalach: 168,
      exang: 0,
      oldpeak: 0.2,
      slope: 2,
      ca: 0,
      thal: 2,
      notes: "Athletic cardiovascular capacity. No symptoms or distress during testing."
    },
    borderline: {
      patient_name: "Robert Hughes (Borderline Test)",
      age: 54,
      gender: "Male",
      cp: 1,
      trestbps: 138,
      chol: 232,
      fbs: 0,
      restecg: 0,
      thalach: 142,
      exang: 0,
      oldpeak: 1.2,
      slope: 1,
      ca: 1,
      thal: 2,
      notes: "Elevated LDL cholesterol with mild resting hypertension."
    }
  };

  const data = samples[type];
  if (!data) return;

  for (const [key, value] of Object.entries(data)) {
    const el = document.getElementById(key);
    if (el) {
      el.value = value;
      el.dispatchEvent(new Event('change'));
    }
  }
}

/**
 * Print or export patient assessment report
 */
function printReport() {
  window.print();
}
